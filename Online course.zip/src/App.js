import React, { Component } from 'react'
import img from "./assests/Rectangle-1.png";
import logo from "./assests/logo.png";
import man from "./assests/1.png";
import man2 from "./assests/2.png";
import man3 from "./assests/3.png";
import './App.css';

export default function App(){
  return( 
    <>
  

  <div class="parent">

 <img src={img}/> 

 <div class="child d-flex justify-content-evenly align-item-center">
<div>
<h4>ALIPRESS</h4>
<h6 class="text-center m-0">CARGO</h6>
</div>
 <div class="btns">
  <button class="btn_1">Login</button>
  <button class="btn_2"> Join Us</button>
 </div>

</div> 

 <div class="container child_2">
<div class="row">
  <div class="col-md-3"></div>
<div class="col-md-4 text">
<h1>Ship your package anywhere. Simple, easy and fast.  </h1>
</div>



<div class="col-md-5 bg-light p-5">
<h4 class="text-dark">Where do you want to send</h4>

<form > 
  <div class="form-row d-flex">
    <div class="col">
    <label> Pick up address</label>
      <input type="text" class="form-control" placeholder="First name"/>
    </div>
    <div class="col">
    <label>Delivery address</label>
      <input type="text" class="form-control right" placeholder="Last name"/>
    </div>
  </div>



  <div class="form-row d-flex mt-4 ">
 
    <div class="col">
      <label> Parcel details</label>
      <input type="text" class="form-control " placeholder="First name" /> 
    </div>
    <div class="col">
    <label>Ship date</label>
      <input type="text" class="form-control right" placeholder="Last name"/>
    </div>
  </div>
  <div class="btn">
  <button type="button" class="btn btn-primary mt-4 ">Primary</button>
  </div>

</form>
</div>


<div class="col-md-1"></div>

</div>
 </div>
</div>
    

<div class="container">
<div class="row">
  <div class="col-md-3"></div>
<div  class="col-md-6 text-center mt-5 second_text">
  <h1>How to send a <span class="inline_text">package with </span>Alirok</h1>
  </div>
  <div class="col-md-3"></div>
    

  </div>
  </div>





  <div class="container">
<div class="row mt-5">
<div class="col-md-2"></div>
  <div class="col-md-3 images">
    <img src={man}/>
    </div>
<div  class="col-md-5 heading mt-4">
   <h1>Enter your origin, destination & package details</h1>
   <div class="d-flex text-align-center pair mt-5">
   <i class="fa-solid fa-check"></i>
<p class="p-0">Review the rates & services and pick your preferred carrier</p>
   </div>


  </div>
  <div class="col-md-2"></div>

  </div>
  </div>








  <div class="container">
<div class="row mt-5">
<div class="col-md-2"></div>

<div  class="col-md-5 heading mt-4">
   <h1>Add sender & recipient Informationails</h1>
   <div class="d-flex text-align-center pair mt-5">
   <i class="fa-solid fa-check"></i>
<p class="p-0">Enter once & done, we will keep you posted about the status of your package</p>
   </div>


  </div>
  <div class="col-md-3 images">
    <img src={man2}/>
    </div>

  <div class="col-md-2"></div>

  </div>
  </div>







  <div class="container">
<div class="row mt-5">
<div class="col-md-2"></div>
  <div class="col-md-3 images">
    <img src={man3}/>
    </div>
<div  class="col-md-5 heading mt-4">
   <h1>Complete payment and print your label</h1>
   <div class="d-flex text-align-center pair mt-5">
   <i class="fa-solid fa-check"></i>
<p class="p-0">Attach the label to the package and we will pick up at your address</p>
   </div>


  </div>
  <div class="col-md-2"></div>

  </div>
  </div>













  <div class="container">
<div class="row mt-5  footer">
<div class="col-md-3 text-muted ">
<h4 class="text-muted">ALIPRESS</h4>
<h6 class="text-muted">CARGO</h6>

<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>

</div>

  <div class="col-md-2 ">
    <h4> Company</h4>
    <ul class="mt-4">
    <li>About</li>
      <li>Career</li>
      <li>Mobile</li>
    </ul>
   
    </div>
<div  class="col-md-2 ">
<h4> Contact</h4>
    <ul class="mt-4">
    <li>Help/FAQ</li>
      <li>Press</li>
      <li>Affliate</li>
    </ul>
   
   </div>


<div class="col-md-2 ">

  <h4> More</h4>
    <ul class="mt-4 ">
    <li>AirLinefree</li>
      <li>AirLine</li>
      <li>Low fair tips</li>
    </ul>
  </div>

 
  <div class="col-md-3">
  <i class="fa-brands fa-facebook"></i>
  <i class="fa-brands fa-instagram"></i>
  <i class="fa-brands fa-twitter"></i>

  
  <h5 class="text-muted"> Discover The APP</h5>
    
    </div>
    </div>
  </div>
 
<p> © 2020 Alirok. All rights reserved</p> 
    
    </>
   
  );
}
     
  
