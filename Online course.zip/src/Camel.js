import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class Wow extends Component {
  static propTypes = {
    prop: PropTypes
  }

  render() {
    return (
      <div>
        <h1> React Practics  {this.props.name}</h1>
      </div>
    )
  }
}
