import './App.css';
import logo1 from './assests/logo1.png'
import logo2 from './assests/logo2.png'
import one from './assests/one.png'
import two from './assests/two.png'
import three from './assests/three.png'
import four from './assests/four.png'

function App(){
  return (

    <>

<div className='container bg_img'>
<nav class="navbar navbar-expand-md bg-body-tertiary">
  <div class="container-fluid icon">
    <div>
   <img src={logo1} alt=''/>
   <img src={logo2} alt=''/>
   </div>
   
   
    <div class=" d-flex justify-content-center nav_gap  text-light" id="navbarSupportedContent ">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 ">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Market</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Artists</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Community</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Wallet</a>
        </li>
         </ul>

   <form class="d-flex align-items-center gap-20" role="search">
        <p className='mb-0'>Login</p>
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>



                                                            {/* {HEADER DATA} */}

<div className='row '>
  <div className='col-md-5 '>
    <div className='header_text text-light '>
<h1>Discover, Collect and Sell Dope NFTs</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipisc elit amet. Consectetu at it lrorem ipsum dolor sit amet.</p>
</div>

<div className='btns'>  
  <button class="btn btn-outline-success btn1" type="submit">Explore</button>
  <button class="btn  btn2" type="submit">Create</button>
</div>


<div className='d-flex gap-5 align-items-center three_divs'>
<div className='data' >
  <h3>80K+</h3>
  <p>Active user</p>
  </div>

  <div className='data'>
  <h3>27K+</h3>
  <p>Artworks</p>
  </div>


  <div className='data'>
  <h3>3.5K+</h3>
  <p>Artists</p>
  </div>

</div>
</div>
</div>
</div>




<div className='container text-white overall_container'>
<div className='row'>
<div className='col-md-4 align-item-center first_div '>
<h1>How it Works</h1>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit amet. Lorem ipsum dolor sit amet, consecte adipiscing elit ipsum.</p>
<div className='gap-20'>
<button >Learn More</button>
</div>
</div>



  <div className='col-md-4 sec_div'>

<div className='div_1'>
  <img src={one}/>
  <h6>Set up Your Wallet</h6>
  <p>Lorem ipsum dolor sit amet, consectetur at adipiscing elit amet</p>
</div>



<div className='div_2'>
  <img src={three}/>
  <h6>Set up Your Wallet</h6>
  <p>Lorem ipsum dolor sit amet, consectetur at adipiscing elit amet</p>
</div>


  </div>




  <div className='col-md-4 sec_div '>
<div className=' div_1'>
  <img src={two}/>
  <h6>Set up Your Wallet</h6>
  <p>Lorem ipsum dolor sit amet, consectetur at adipiscing elit amet</p>
</div>

<div className='div_2'>
  <img src={four}/>
  <h6>Set up Your Wallet</h6>
  <p>Lorem ipsum dolor sit amet, consectetur at adipiscing elit amet</p>
</div>

</div>

</div>

</div>






     
    </>
  );
}

export default App;
