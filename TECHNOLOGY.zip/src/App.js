import './App.css';
import React from 'react';
import logo from './assests/logo.png'
import one from './assests/1.png'
import two from './assests/2.png'
import three from './assests/3.png'
import four from './assests/4.png'
import email from './assests/email.png'
import sec_block from './assests/sec_block.jpg'
import one_img from './assests/one_img.png'
import two_img from './assests/two_img.png'
import three_img from './assests/three_img.png'
import four_img from './assests/four_img.png'
import play_btn from './assests/play_btn.png'
import tool_img from './assests/tool_img.png'
import five1_img from './assests/five1_img.png'
import five2_img from './assests/five2_img.png'
import five3_img from './assests/five3_img.png'
import mailbox from './assests/mailbox.jpg'
import mail from './assests/mail.png'
function App() {
  return (
    <>

      {/* NAVBAR */}


      <nav class="navbar navbar-expand-md bg-body-tertiary nav_shadow ">
        <div class="container">
           <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button> 
          <div class="collapse navbar-collapse nav_bar " id="navbarTogglerDemo01">

            <img src={logo} alt="Logo" height='80px' width='80px' />
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 gap-4 nav_font ">
              <li class="nav-item">
                <a class="nav-link active " aria-current="page" href="#">Pages</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"> <span><img src={one} /></span> &nbsp;Categories</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><span><img src={two} /></span> &nbsp;Blog</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"> <span><img src={three} /></span> &nbsp;Reviews</a>
              </li>
              <li class="nav-item">
                <a class="nav-link"><span><img src={four} /></span> &nbsp; Buying Guides</a>
              </li>
            </ul>
            <div className="d-flex nav_font" role="search">
              <p><span><img src={email} /></span> &nbsp;Sign Up</p>
            </div>

          </div>
        </div>
      </nav>






      {/* SECOND BLOCK */}



      <div className='container sec_div '>
        <div class="row g-0 bg-body-secondary position-relative inner_gap">
          <div class="col-md-6 mb-md-0 p-md-4">
            <img src={sec_block} width='100%' height='300px' alt="..." />
          </div>
          <div class="col-md-6 p-4 ps-md-0 m-0 sec_div_text">
            <h6 class="mt-0">Introducing Affiliate Template for Webflow</h6>
            <h1>Easy-to-use Template for building Affiliate Sites</h1>
            <p><b>Affiliate </b>is a Webflow template made for entrepreneurs who want a professional and polished site ready to start and grow their affiliate marketing business in any niche marketing business in any nich.</p>
            <button type="button" class="btn btn-success sec_div_btn">Buy this Template</button>
          </div>
        </div>


      </div>




      {/* THIRD BLOCK */}


      <div className='container third_div '>
        <h3>Latest from the Blog</h3>
        <div className='row'>
          <div className='col-md-6 third_first_div'>
            <img src={one_img} alt='nature' width='90%' height='250px' />
            <h5>How to Prep Your Lawn in the Spring</h5>
            <p>This is the blog description text. This is the blog description text. This is the blog description text.</p>

          </div>


          <div className='col-md-6 '>
            <div className='d-flex align-items-center  third_div_text'>
              <img src={two_img} alt='nature' width='40%' height='100px' className='img_mar' />
              <p>Secrets to Know About Hedge Trimming</p>
            </div>



            <div className='d-flex align-items-center third_div_text'>
              <img src={three_img} alt='nature' width='40%' height='100px' className='img_mar' />
              <p>What to Do With a Dying Tree</p>
            </div>




            <div className='d-flex align-items-center third_div_text'>
              <img src={four_img} alt='nature' width='40%' height='100px' className='img_mar' />
              <p>Which Flowers Should You Plant Garden</p>
            </div>



          </div >

          <div className='seperate_div'>
            <p><span> <img src={play_btn} alt=".." /></span> &nbsp; View All Blog Articles</p>
          </div>
        </div>
      </div>


      {/* FOURTH BLOCK */}



        <div class="container four_div ">
          <div className='row'>
            <div className='d-flex justify-content-between media_adjust'>
            <div className='d-flex align-items-center gap-2'>
          <img src={tool_img} alt='' />
       <p> &nbsp; View our list of the best products in lawncare.</p>
       </div>
      <button class="btn btn-outline-success bg-success text-white" >see the list</button>
      </div>
            </div>
     </div>
     {/* grid based */}
     <div class="container four_div ">
          <div className='row align-items-center'>
            <div className='col-md-10 d-flex gap-20 flex-wrap align-items-center justify-center-mb mb-tool'>
            <img src={tool_img} alt=''  className='mb-tool'/>
            <p> &nbsp; View our list of the best products in lawncare.</p>
            </div>
            
            <div className='col-md-2 text-center mb-tool'>
            <button class="btn btn-outline-success bg-success text-white" >see the list</button>
            </div>
         
            </div>
     </div>

                                                       {/* FIFTH BLOCK */}




      <div className='container five_div'>
        <h3>Latest Product Reviews</h3>

        <div className='row'>
          <div className='col-md-4'>


            <div className='five_cards'>
              <img src={five1_img} class="card-img-top" alt="..." />
              <div className='five_cards_text'>
                <h5 >Lawnmower Xtreme</h5>
                <p>This is the Review Snippet. This is the Review Snippet. This is the Review Snippet. This is the Review Snippet.</p>

              </div>
            </div>
          </div>



          <div className='col-md-4'>


            <div className='five_cards'>
              <img src={five2_img} class="card-img-top" alt="..." />
              <div className='five_cards_text'>
                <h5 >Ultra Grow Fertilizer</h5>
                <p>This is the Review Snippet. This is the Review Snippet. This is the Review Snippet. This is the Review Snippet.</p>

              </div>
            </div>
          </div>




          <div className='col-md-4'>


            <div className='five_cards'>
              <img src={five3_img} class="card-img-top" alt="..." />
              <div className='five_cards_text'>
                <h5>Hedge Clippers</h5>
                <p>This is the Review Snippet. This is the Review Snippet. This is the Review Snippet. This is the Review Snippet.</p>

              </div>
            </div>
          </div>

        </div>


        <div className='seperate_div'>
            <p><span> <img src={play_btn} alt=".." /></span> &nbsp; View All Blog Articles</p>
          </div>

      </div>


                                                       {/* SIX_BLOCK */}

    <div className='container six_div'>                                          
    <div class="row g-0 bg-body-secondary six_data ">
  <div class="col-md-6 mb-md-0 p-md-4  ">
    <img src={mailbox}  width='90%'  alt="..."/>
  </div>
  <div class="col-md-6 p-4 ps-md-0   ">
    <div className='d-flex six1_div'>
    <img src={mail} width='10%' height='50px' />
    <h5 class="mt-0">Newsletter Signup</h5>
   
    </div>
<div className='six_para'>
    <p>Be the first to receive updates on articles, product reviews, courses, and more!</p>
    </div>

   
    
    <input type="Email" placeholder='Your Email' class="form-control" />

    <div className='d-flex six_btn align-items-center'>
    <button type="button" class="btn btn-warning">Submit</button>
    <p>Privacy Policy</p>
    </div>
  
  
    

    </div>


  
</div>
</div>



                                                    {/* FOOTER BLOCK */}


<div className='container footer '>
<div className='row'>
<div className='col-md-3 footer_para '>
  <img src={logo} height='80px' width='80px'/>
<div className='icons'>
  <i class="fa-brands fa-facebook"></i>
  <i class="fa-brands fa-twitter"></i>
  <i class="fa-brands fa-instagram"></i>
  </div>
  <p><b>Affiliate</b> is a Webflow template made for entrepreneurs who want a professional and polished site ready to start and grow their affiliate marketing business in any niche.</p>
</div>





<div className='col-md-5 footer_middle'>
<h4>Latest Articles</h4>

<div className='d-flex align-items-center  third_div_text'>
              <img src={two_img} alt='nature' width='40%' height='80px' className='img_mar rounded' />
              <p>Secrets to Know About Hedge Trimming</p>
            </div>



            <div className='d-flex align-items-center third_div_text'>
              <img src={three_img} alt='nature' width='40%' height='80px' className='img_mar rounded' />
              <p>What to Do With a Dying Tree</p>
            </div>



           <div className='d-flex align-items-center third_div_text'>
              <img src={four_img} alt='nature' width='40%' height='80px' className='img_mar rounded' />
              <p>Which Flowers Should You Plant Garden</p>
            </div>
</div>




<div className='col-md-4  footer_middle'>
<h4>Browse</h4>
<div class="input-group mb-3">
  <input type="text" class="form-control" aria-label="Recipient's username" aria-describedby="button-addon2"/>
  <button class="btn btn-outline-secondary" type="button" id="button-addon2">Search</button>
  </div>
  <ul className='footer_list'>
<li>About</li>
<li>Categories</li>
<li>Tools</li>
<li>Contact</li>
<li>Privacy Policy</li>
<li>Affiliate Disclosure</li>
 </ul>
 
<hr/>
<p>©2022 Your Brand Name</p>
</div>

</div>
 
</div>

<hr/>
<div className='d-flex  justify-content-around final'>
  <div className='d-flex  gap-3'><p>Style Guide</p>
  <p>Licenses</p>
  <p> Changelog</p>
  </div>

  <div>

    <p> Powered by Webflow.Designed by Kevin Barrett</p>
  </div>
</div>







    </>

  );
}

export default App;
