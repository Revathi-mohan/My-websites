
import './App.css';
import logo from './assests/logo.jpg'
import man from './assests/men.png'
import phone from './assests/phone.jpeg'
import mobile from './assests/mobile.png'
import mobile2 from './assests/mobile2.jpeg'
import men1 from './assests/1.jpeg'
import women1 from './assests/2.jpg'
import img1 from './assests/123.png'
import one from './assests/ONE.jpg'
import two from './assests/TWO.png'
import three from './assests/THREE.jpg'
import four from './assests/FOUR.png'
import lady from './assests/lady.jpeg'
import logos from './assests/logos.jpeg'
function App() {
  return (
    <>
                                                      {/* {NAV BAR} */}
                                                      <div className="container">
  <nav className="navbar navbar-expand-lg bg-body-tertiary">
 
    <a className="navbar-brand" href="#"><img src={logo} width="80px" height="40px" /></a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0  ">
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="#">Link</a>
        </li>
        <li className="nav-item dropdown">
          <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul className="dropdown-menu">
            <li><a className="dropdown-item" href="#">Action</a></li>
            <li><a className="dropdown-item" href="#">Another action</a></li>
            <li><hr className="dropdown-divider"/></li>
            <li><a className="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li className="nav-item">
          <a className="nav-link disabled">Disabled</a>
        </li>
      </ul>
      
    </div>
  
</nav>
</div>






















{/* <div className="container">
<div className='row'>
<div className='col-md-12 '>
  <div className='d-flex justify-content-around mt-3'>
<img src={logo} width="80px" height="40px" />
<ul className='d-flex gap-5 alight-items-center nav_items mt-2'>
<li>Services</li>
<li>What we Do </li>
<li>Services</li>
<li>Pages</li>
<li>FAQ</li>
</ul>
</div>
  

</div>
</div>
</div> */}




                                                       {/* {Header} */}
                                                       
<div className='container-fluid header'>
  <div class="row g-0 bg-light  header-content ">
<div class="col-md-2"></div>
  <div class="col-md-4 p-4 ps-md-0  mt-5 header_text ">
    <h1 class="mt-0  main_head">Solutions Rooted in Code Ans Design</h1>
    <ul>
<li>series of sentences that are organized and coherent</li>
<li> Almost every piece of writing you do that is longer</li>
<li>Good paragraphs begin with a topic sentence that briefly explains what the paragraph is about. Next come a few sentences </li>
    </ul>
    <div className='d-flex gap-5 align-items-center header_btn'>
    <button type="button" class="btn btn-warning" >Buy Now For -15$</button>
    <p className='m-0 '>Take Quick Tour</p>
    </div>
  </div>

  <div class="col-md-6 mb-md-0 p-md-4">
    <img src={man} />
  </div>
  
</div>
</div>





                                                                        {/* body SECTION */}

<div className='container'>
<div class="row g-0 bg-light position-relative mt-5">
  <div class="col-md-1"></div>
  <div class="col-md-5 mb-md-0 p-md-4">
    <img src={phone} width="400px" height="400px"/>
  </div>
  <div class="col-md-5 p-4 ps-md-0 body_text">
    <h6 class="mb-4 p-0">Beauty of Simplicity</h6>
    <h1 class="mb-4">We Are Making do better for everyone</h1>
    <p>Another instance of placeholder content for this other custom component.  like, and we're using it here to give the component a bit of body and size.</p>
    <h5 class="mb-2">Features Never Stop</h5>
<div className='m-0 p-0'>
<ul type='circle' >
<li>series of sentences that are organized and coherent  </li>
<li> Almost every piece of writing you do that is longer</li>
<li>Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come  </li>
    </ul>
</div>

    
  </div>
  <div class="col-md-1"></div>
</div>
</div>





                                                                            {/* CARD SECTION */} 



 <div className="container">
<div className='row mt-5'>
<div class="col-md-3 "></div>
<div className='col-md-6 text-center cards_para'>
<h1>What Makes Shiftkey Different</h1>
<p >Online Grammar and Writing Checker To Help You Deliver Impeccable, Mistake-free Writing.
 Grammarly Has a Tool For Just About Every Kind Of Writing You Do</p>
</div>
<div class="col-md-3"></div>

</div>
</div>


                                                             {/* THREE CARDS  */}


<div className='container'>
  <div className="row mt-5">
    <div className='col-md-4'>
<div class="card1 text-center ">
  <div class="card-body mt-5">
    <h4 class="card-title">Special title treatment</h4>
    <p class="card-text mt-3">The first sentence in a paragraph is sometimes called the key or topic sentence because it gives us the key to what the paragraph will be about. The other sentences usually relate to the key sentence.</p>
    

    <div className='child_icon'><i class="fa-solid fa-table-cells-large"></i></div>
  </div>
  </div>
</div>


<div className='col-md-4'>
<div class="card1 text-center ">
  <div class="card-body mt-5">
    <h4 class="card-title">Special title treatment</h4>
    <p class="card-text mt-3">The first sentence in a paragraph is sometimes called the key or topic sentence because it gives us the key to what the paragraph will be about. The other sentences usually relate to the key sentence.</p>
    

    <div className='child_icon'><i class="fa-solid fa-table-cells-large"></i></div>
  </div>
  </div>
</div>




<div className='col-md-4'>
<div class="card1 text-center ">
  <div class="card-body mt-5">
    <h4 class="card-title">Special title treatment</h4>
    <p class="card-text mt-3">The first sentence in a paragraph is sometimes called the key or topic sentence because it gives us the key to what the paragraph will be about. The other sentences usually relate to the key sentence.</p>
    

    <div className='child_icon'><i class="fa-solid fa-table-cells-large"></i></div>
  </div>
  </div>
</div>
</div>
</div>

                                                        {/* THREE BELOW DESIGN  */}


<div className='container'>
<div class="row g-0 bg-light position-relative mt-5">
  <div class="col-md-2"></div>
  
  <div class="col-md-4 p-4 ps-md-0 body_text">
    <h6 class="mb-4 p-0">Totally Optimized</h6>
    <h1 class="mb-4">We Provided  wide Range of the services</h1>
    <p>Another instance of placeholder content for this other custom component.  like, and we're using it here to give the component a bit of body and size.</p>
    <h5 class="mb-2">Features Never Stop</h5>
<div className='m-0 p-0 list_type'>
<ul type='dot' >
<li>series of sentences that are organized and coherent Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come  </li>

<li className='mt-3'>Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come   </li>
    </ul>
</div>
</div>

<div class="col-md-6 mb-md-0 p-md-4">
    <img src={mobile} width="600px" height="400px"/>
  </div> 
  
</div>
</div>



                                                        {/* FIVE DESIGN  */}


<div className="container-flui per_block">
<div className='row mt-5'>
<div class="col-md-3 "></div>
<div className='col-md-6 text-center cards_para'>
<h2>With Knolwledge,  Skills & Hard Work</h2>
<p  >Online Grammar and Writing Checker To Help You Deliver Impeccable, Mistake-free Writing.
 Grammarly Has a Tool For Just About Every Kind Of Writing You Do</p>
</div>
<div class="col-md-3"></div>

</div>


<section className="d-flex justify-content-center flex-wrap">

  <div className='div_one'>
    <h1>38%</h1>
    <p>Fast Food Time</p>
  </div>

  <div className='div_one'>
    <h1>47%</h1>
    <p>More Productivity</p>
  </div>

  <div className='div_one'>
    <h1>43%</h1>
    <p>Less RAM Loading</p>
  </div>

</section>

</div>


                                                       {/*SIX DESIGN  */}


<div className='container'>
<div class="row g-0 bg-light position-relative mt-5">
  <div class="col-md-1"></div>
  <div class="col-md-5 mb-md-0 p-md-4">
    <img src={mobile2} width="400px" height="450px"/>
  </div>
  <div class="col-md-5 p-4 ps-md-0 mt-5">
   <div class='d-flex align-item-center six_div mb-3'>
   <i class="fa-solid fa-circle-plus"></i>
    
    <div>
      <h5>Extened Features</h5>
      <p>We organise what we write into sentences and paragraphs. A paragraph begins on a new line within the text and there is often a blank line between paragraphs</p>
    </div>

    </div>




    <div class='d-flex align-item-center six_div mb-3'>
    <i class="fa-solid fa-bars"></i>
    <div>
      <h5>Transperent Workflow</h5>
      <p>We organise what we write into sentences and paragraphs. A paragraph begins on a new line within the text and there is often a blank line between paragraphs</p>
    </div>
     </div>



    <div class='d-flex align-item-center six_div mb-3'>
    <i class="fa-solid fa-magnifying-glass"></i>
    <div>
      <h5>SEO & SMM Services</h5>
      <p>We organise what we write into sentences and paragraphs. A paragraph begins on a new line within the text and there is often a blank line between paragraphs</p>
    </div>
    </div>
    </div>

  <div class="col-md-1"></div>
</div>
</div>

                                                    {/*SEVEN DESIGN  */}

      <div className="container seven_first">
        
        <div className='row'>
        <div className='col-md-1'></div>
        <div className='col-md-4 seven_div'>
          <div>
            <h6> OUR CUSTOMERS</h6>
            <h1> 10K+ Customers Love Shiftkey</h1>
            <p>Almost every piece of writing you do that is longer than a few sentences should be organized into paragraphsyou do that  paragraphs do that  paragraphs</p>
          <button>FIND OUT MORE</button>
          </div>
        </div>
        
        <div className='col-md-3 seven_Sec_div seven_first'>
          
          <div >
          <section className='d-flex gap-3 '>
          <img src={men1} />
<div >
<h6>PEB213</h6>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</div>
</section>
<p className='mt-3'><i>A paragraph is a group of connected usually consists five to ten sentences of approx. ten words. Generally paragraph begins with indentation (about five spaces) and new paragraph starts with new lines by missing a line out</i></p>
</div> 
</div>


 


<div className='col-md-3 seven_Sec_div seven_first '>
<div classname="gap">
          <div className='side_block'>
          <section className='d-flex gap-3 '>
          <img src={men1} />
<div>
<h6>PEB213</h6>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</div>
</section>
<p className='mt-3'><i>A paragraph is a group of connected usually consists five to ten sentences of approx. ten words. Generally paragraph begins with indentation (about five spaces) and new paragraph starts with new lines by missing a line out</i></p>
</div>
</div> 
</div>

                               {/* SECOND DIVISION */}

<div className='container'>


  <div className='row'>
  <div className='col-md-5'></div >

  <div className='col-md-3 seven_Sec_div '>
          <div className='mb-5'>
          <section className='d-flex gap-3 '>
          <img src={men1} />
<div >
<h6>PEB213</h6>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</div>
</section>
<p className='mt-3'><i>A paragraph is a group of connected usually consists five to ten sentences of approx. ten words. Generally paragraph begins with indentation (about five spaces) and new paragraph starts with new lines by missing a line out</i></p>
</div> 
</div>


 


<div className='col-md-3  seven_Sec_div'>
          <div className='mb-5'>
          <section className='d-flex gap-3 '>
          <img src={men1} />
<div >
<h6>PEB213</h6>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
<i class="fa-solid fa-star"></i>
</div>
</section>
<p className='mt-3'><i>A paragraph is a group of connected usually consists five to ten sentences of approx. ten words. Generally paragraph begins with indentation (about five spaces) and new paragraph starts with new lines by missing a line out</i></p>
</div> 
</div>


  </div >
</div>






</div>     
</div>                                    





                                                          {/*SOFTWARE BLOCK */}
 <div className='container software'>
    <div className='row'>
    <div className='col-md-3'></div>
    <div className='col-md-6'>
   <h2 className='text-center'>Something different, Something New</h2>
   <p className='text-center'>Paragraphs are the building blocks of papers. Many students define paragraphs in terms of length: a paragraph is a group of at least five sentences</p>
   
</div>
<div className='col-md-3'></div>
</div>



<div className='row'>
<div className='col-md-2'></div>
<div className='col-md-8'>
  <img src={img1}  height='500px' className='mr-5'/>
</div>
<div className='col-md-2 '></div>
</div>
 </div>

                                         {/*VEDIO BLOCK */}
<div className='container-fluid'>
</div>

                                         {/*LARGE ICONS BLOCK */}


<div className='container responsive'>
  <p className='text-center'> Provide specific details about what something looks</p>
  <div className='row'>

  <div className='col-md-1'> </div> 
  <div className='col-md-10'>
    <div className='d-flex justify-content-around flex-wrap images'>
   <div > <img src={four}/> </div>
   <div> <img src={one} /> </div>
   <div> <img src={one} /> </div>
   <div> <img src={two}/> </div>
  <div> <img src={three}/> </div>
   <div> <img src={three}/> </div>
   <div> <img src={four}/> </div> 
    
    </div>
  </div>
<div className='col-md-1'> </div> 
  </div>

</div>

                                             {/*EIGHT DESIGN  */}

<div className='container'>
<div class="row g-0 bg-light position-relative mt-5">
  <div class="col-md-2"></div>
  
  <div class="col-md-5 p-4 ps-md-0 body_text">
    <h6 class="mb-4 p-0">Beauty of simplicity</h6>
    <h1 class="mb-4">Enchance Your Website design with shitkey</h1>
    
<div className='m-0 p-0 list_type'>
<ul type='dot' >
<li>series of sentences that are organized and coherent Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come  </li>

<li className='mt-3'>Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come   </li>
    </ul>
</div>
</div>

<div class="col-md-5 mb-md-0 p-md-4">
    <img src={lady}  height="400px"/>
  </div> 
  
</div>
</div>

                                          {/*FOOTER ABOVE DESIGN  */}




    <div className='container '>
    <div className='row'>
    <div className='col-md-3'></div>
    <div className='col-md-6'>
   <h2 className='text-center'>Something different, Something New</h2>
   <p className='text-center'>Paragraphs are the building blocks of papers. Many students define paragraphs in terms of length: a paragraph is a group of at least five sentences</p>
   
</div>
<div className='col-md-3'></div>
</div>
</div>

<div className='container footer_above'>

<div className='row'>
<div className='col-md-2'>
</div>

<div className='col-md-4  colum_block  '>
<div>
<h6>Do you have non-profit discount</h6>
<p>here is no specific format for writing a paragraph, as it is a narration of your own thoughts</p>

</div>


<div>
<h6>Do you have Free Trail</h6>
<div className='m-0 p-0'>
<ul type='dot m-0 p-0' >
<li>series of sentences that are organized and coherent  </li>
<li> Almost every piece of writing you do that is longer</li>
<li>Good paragraphs begin with a topic sentence that briefly what the paragraph is about. Next come  </li>
    </ul>
</div>
</div>


<div>
<h6>How do install a shiftkey</h6>
<p>here is no specific format for writing a paragraph, here is no specific format for writing a paragraph, as it is a narration of your own thoughts</p>

</div>
</div>
















<div className='col-md-4'>

<div>
<h6>Do you have Free Trail</h6>
<div className='m-0 p-0'>
<ul type='dot m-0 p-0' >
<li>series of sentences that are organized and coherent  </li>
<li> Almost every piece of writing you do that is longer the paragraph is about</li>

    </ul>
</div>
</div>


 
<div className='middle'>
<h6>How do install a shiftkey  </h6>
<p>here is no specific format for writing a paragraph, as it is a narragraph,as it is a narragraph,  </p>
</div>


<div>
<h6>How do install a shiftkey  </h6>
<p>here is no specific format for writing a paragraph,  a paragraph, as it is a a paragraph, as it is aas it is a narragraph,as it is a narragraph,</p>

</div>




</div>
<div className='col-md-2'>
</div>
</div>

</div>







<p className='text-center'>Still have a question? <a href='#'><b>Ask Your Question here</b></a></p>






<div className='container mt-5'>
<div className='row'>

<div className='col-md-3'>

<a className="navbar-brand" href="#"><img src={logos} height="80px" /></a>
<div className='footer_div'>
<p>E: hello@gmail.com</p>
<p>P: +12536578566</p>
</div>
<div className='d-flex gap-3'>
<i class="fa-brands fa-facebook"></i>
<i class="fa-brands fa-twitter"></i>
<i class="fa-brands fa-google-plus-g"></i>
<i class="fa-solid fa-turkish-lira-sign"></i>
</div>
</div>

<div className='col-md-2'>
</div>

<div className='col-md-2'>
<h6>Products</h6>
<ul className='list-style'>
  <li>How it works?</li>
  <li>Integration</li>
  <li>Product Updates</li>
  <li>Our Pricing</li>
  <li>FAQS</li>
</ul>
</div>

<div className='col-md-2 '>
<h6 >Company</h6>
<ul className='list-style'>
  <li>About Us</li>
  <li>Careers</li>
  <li>Press $ Media </li>
  <li>Our Blog</li>
  <li>Advetising</li>
</ul>
</div>

<div className='col-md-3'>
<h6>Scbscribed Us</h6>
<p> A paragraph is a group of connected sentences on any topic</p>



<div class="input-group">
<input type="text" aria-label="Email Adress" class="form-control" placeholder='Email Adress'/>
  <span class="input-group-text"><i class="fa-regular fa-envelope"></i> </span>
  
 
</div>




</div>


  
</div>
</div>

<hr/>

    
    </>
  );
}

export default App;
